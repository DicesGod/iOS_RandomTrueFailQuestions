import UIKit

struct Question{
    var A = 0
    var B = 0
    var question = ""
    var correctAnswer = false
}

var list = [1,2,3,4,1]
var listQuestions = [Question]()


func generateQuestions(list: Array<Int>) -> Void{
    for i in 0..<list.count-1{
        for y in i+1..<list.count{
        if (list[i] < list[y])
        {
            listQuestions.append(Question(A: list[i], B: list[y],question:String(list[i])+" is smaller than "+String(list[y])+" ? TRUE or FALSE",correctAnswer:true))
            listQuestions.append(Question(A: list[i], B: list[y],question:String(list[i])+" is bigger than "+String(list[y])+" ? TRUE or FALSE",correctAnswer:false))
        }
        else{
            listQuestions.append(Question(A: list[i], B: list[y],question:String(list[i])+" is smaller than "+String(list[y])+" ? TRUE or FALSE",correctAnswer:false))
            listQuestions.append(Question(A: list[i], B: list[y],question:String(list[i])+" is bigger than "+String(list[y])+" ? TRUE or FALSE",correctAnswer:true))
        }
    }
    }
    //print(listQuestions)
}

generateQuestions(list:list)

func randomDisplayQuestions(questionsList: Array<Question>) -> Void{
    var tempQuestionsList = questionsList
    print(tempQuestionsList.count)
    var usedQuestions = [Question]()
    var count = 0
    repeat{
    let randomNumber = Int.random(in: 0 ..< tempQuestionsList.count)
    usedQuestions.append(tempQuestionsList[randomNumber])
    tempQuestionsList.remove(at: randomNumber)
    count = count+1
        
      
        
        for i in 0..<usedQuestions.count-1{
            for y in i+1..<usedQuestions.count{
                if((usedQuestions[i].A == usedQuestions[y].A && usedQuestions[i].B == usedQuestions[y].B)||(usedQuestions[i].A == usedQuestions[y].B && usedQuestions[i].B == usedQuestions[y].A)){
                    usedQuestions.remove(at: y)
                    count = count-1
                    
                    break
               
                }
            }
        }
    }
    while (count < 5)
    print(usedQuestions)
}

randomDisplayQuestions(questionsList: listQuestions)
